<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadDir = "uploads/";
    $uploadFile = $uploadDir . basename($_FILES["proof_of_payment"]["name"]);

    // Ensure upload directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Check file type
    $fileType = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));
    $allowedTypes = ["jpg", "jpeg", "png", "pdf"];

    if (!in_array($fileType, $allowedTypes)) {
        echo "Error: Unsupported file format.";
        exit();
    }

    // Move file to uploads directory
    if (move_uploaded_file($_FILES["proof_of_payment"]["tmp_name"], $uploadFile)) {
        echo "<script>document.querySelector('.success-message').style.display = 'block';</script>";
    } else {
        echo "Error: File upload failed.";
    }
}
?>
