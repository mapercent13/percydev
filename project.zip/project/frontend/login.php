<?php
require 'vendor/autoload.php'; // Include Composer's autoloader

use Kreait\Firebase\Factory;
use Kreait\Firebase\Auth;

$factory = (new Factory)->withServiceAccount('path/to/your/firebase_credentials.json'); // Path to your Firebase credentials JSON file
$auth = $factory->createAuth();

// Start session
session_start();

// Handle registration
if (isset($_POST['register'])) {
    $email = $_POST['kgotsoedwin62@gmail.com'];
    $password = $_POST['12345678'];
    $first_name = $_POST['Kg'];
    $last_name = $_POST['NAPE'];

    try {
        $user = $auth->createUserWithEmailAndPassword($email, $password);
        // Optionally, you can store additional user information in your database
        echo "Registration successful. You can now log in.";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}

// Handle login
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $signInResult = $auth->signInWithEmailAndPassword($email, $password);
        $_SESSION['user_id'] = $signInResult->firebaseUserId();
        $_SESSION['email'] = $email; // Store email or other user info as needed
        header("Location: index.html"); // Redirect to home page
        exit();
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

