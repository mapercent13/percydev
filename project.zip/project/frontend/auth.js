import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.7.2/firebase-auth.js";
import { getFirestore, setDoc, doc } from "https://www.gstatic.com/firebasejs/10.7.2/firebase-firestore.js"; // Firestore to store user details
import { app } from 'firebase.js'; // your Firebase config

const auth = getAuth(app);
const db = getFirestore(app);

// LOGIN FUNCTION
window.login = function () {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            console.log("✅ Login successful!", userCredential.user);
            alert("Login Successful!");
            window.location.href = "index.html"; // Redirect to your dashboard
        })
        .catch((error) => {
            console.error("❌ Login failed!", error.message);
            alert(error.message);
        });
};

// SIGNUP FUNCTION
window.signUp = function () {
    const firstName = document.getElementById("first-name").value;
    const lastName = document.getElementById("last-name").value;
    const email = document.getElementById("signup-email").value;
    const password = document.getElementById("signup-password").value;

    // Create user with Firebase Authentication
    createUserWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
            console.log("✅ Signup successful!", userCredential.user);

            // Store the additional user details (Name & Surname) in Firestore
            const user = userCredential.user;
            setDoc(doc(db, "users", user.uid), {
                firstName: firstName,
                lastName: lastName,
                email: email,
            })
            .then(() => {
                console.log("✅ User details saved in Firestore!");
                alert("Account Created! You can now log in.");
                window.location.href = "login.html";  // Redirect to login page after successful sign up
            })
            .catch((error) => {
                console.error("❌ Error saving user details in Firestore:", error.message);
                alert("Error saving your information. Please try again.");
            });
        })
        .catch((error) => {
            console.error("❌ Signup failed!", error.message);
            alert(error.message);
        });
};

// OPTIONAL: Function to switch between login and signup forms
window.toggleForms = function () {
    const loginForm = document.getElementById("login-form");
    const signupForm = document.getElementById("signup-form");
    
    if (loginForm.style.display === "none") {
        loginForm.style.display = "block";
       
        signupForm.style.display = "none";
    } else {
        loginForm.style.display = "none";
        signupForm.style.display = "block";
    }
};
